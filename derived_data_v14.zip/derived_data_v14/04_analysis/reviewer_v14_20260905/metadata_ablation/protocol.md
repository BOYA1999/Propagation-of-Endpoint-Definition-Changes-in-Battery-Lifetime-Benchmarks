# Source and chemistry indicator ablation

This analysis tests whether prediction movement and model selection depend on explicit source and chemistry indicators. Ridge and XGBoost use the same 126 early-cycle numerical summaries as the main experiment, with the two categorical indicators omitted. The curves may still encode source information.

The cohort comprises 823 cells, split into 503 training, 162 calibration and 158 test cells. Both endpoint-label contracts, the log1p target transform, StandardScaler, prediction floor of one cycle, model settings and evaluation definitions are fixed. Seeds are 0–19, 42, 2021 and 2024. XGBoost retains its target-adaptive initial intercept. No hyperparameter or feature selection is performed.

Training consists of 46 XGBoost fits and two deterministic Ridge fits. Ridge predictions are copied to the 23 seed indices; those indices do not represent independent Ridge refits. The two deep-model prediction sets are reused from the main experiment.

The fit process reads the features and the two training-label files, then saves calibration and test predictions. Evaluation runs separately and reads the held-out labels.

The prediction-movement analysis uses 5,000 paired-seed and within-source-cell bootstrap replicates. The ordinary-refit denominator is the median of the pooled A and B within-contract pairwise distances. Draws and model ordering match the main analysis. Point estimates and bootstrap medians are reported separately for all, changed-label and unchanged-label test cells.

Model selection is described by 230 rank-one opportunities and 115 matched-contract comparisons across five metrics. Winner changes, full-order agreement and top-two agreement are reported without a post hoc practical-equivalence threshold.

The archived fits used Python 3.12.0, NumPy 1.26.4, pandas 2.3.3, scikit-learn 1.8.0 and XGBoost 3.3.0, with one XGBoost CPU worker. This public description preserves the analysis settings. The protocol hash in the archived training configuration identifies the original execution record, not this shortened description.
