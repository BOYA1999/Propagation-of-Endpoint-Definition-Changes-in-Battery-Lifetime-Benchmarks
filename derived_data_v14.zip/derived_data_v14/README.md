# Derived data for the endpoint-definition analysis

This archive contains the paired labels, early-cycle feature table, stored predictions, run records, endpoint traces and reference tables used by the v14 code release. Extract the enclosing `derived_data_v14/` directory beside the repository README, preserving the relative paths.

Run `python scripts/reproduce.py --data-root derived_data_v14 --output results` from the code repository. The command verifies `MANIFEST.json` before reading the inputs and writes its calculations to a separate directory.

The main experiment contains 823 cells in a fixed 503/162/158 split and 23 seed indices. The metadata ablation removes explicit source and chemistry indicators from the classical models and reuses the deep-model predictions. Frozen configurations and training logs describe the original fits. Their source and protocol hashes identify those original records, not the public command-line adaptations or the shortened protocol description.

The CSV evidence is preserved from the analysis archive. Default coordinate and Tongji checks validate supplied derived traces; reconstructing them from processed objects requires the external inputs documented in the code repository. Raw battery objects, sequence tensors, weights and manuscript files are not included.

BatteryLife processed data and source-derived labels are attributed to Zenodo record 21149533, https://doi.org/10.5281/zenodo.21149533, under CC BY 4.0. The derived tables do not replace the upstream distribution or its terms. See `DATA_SOURCES.md` and `THIRD_PARTY_NOTICES.md` in the code repository for additional source attribution and the ISU lineage resources.
